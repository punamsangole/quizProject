package com.quiz;
import java.util.Map;
import java.util.Set;


	public class PrintQuestions {
		
		public void printQ() {

			int score = 0;
			AllQuestionsData allQuestionsData = new AllQuestionsData();

			Map<Integer, Map<String, String>> questionsData = allQuestionsData.getQuestionsData();

			Set<Integer> keySet = questionsData.keySet();

			int qNo = 1;
			for (Integer key : keySet) {

				System.out.print("Question No. " + qNo + "> ");
				qNo++;
				Map<String, String> singleQ = questionsData.get(key);

				

				DisplaySingleQ displaySingleQ = new DisplaySingleQ();

				score = score + displaySingleQ.workOnQ(singleQ);

				System.out.println();
				System.out.println("--");

			}

			System.out.println();
			System.out.println("Your Score is " + score + " out of 10.");

			System.out.println();
			

			if (score >= 8) {
				//
				System.out.println("You Got Class A.");

			} else if (score >= 6) {

				System.out.println("You Got Class B.");

			} else if (score == 5) {

				System.out.println("You Got Class C.");

			} else if (score < 5) {
				System.out.println("You Got Class D.");
			}

			InsertScoreDB insertScoreDB = new InsertScoreDB();

			boolean isScoreSave = insertScoreDB.saveScore(score);
			if (!isScoreSave) {
				System.out.println(" ");
				System.out.println();
				System.out.println("Something went wrong..................Your score is not saved in data");
			}
		}

		public static void main(String[] args) {
			PrintQuestions printQuestions = new PrintQuestions();
			printQuestions.printQ();

		}

	}


