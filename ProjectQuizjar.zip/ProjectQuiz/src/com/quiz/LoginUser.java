package com.quiz;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
	
public class LoginUser {
	
		
		public void userLogin() {
		
		
		 Scanner scanner = new Scanner(System.in);
		
		 AllUserData allUserData = new AllUserData();
		
		 Map<Integer, Map<String, String>> allUsers = allUserData.getUsers();
		
		 System.out.println("Please enter the username: ");
		 String userName = scanner.next();
		
		 System.out.println("Please enter the password: ");
		 String password = scanner.next();
		
	     System.out.println();
		 Set<Integer> usersKeys = allUsers.keySet();
		
		 boolean isUser = false;
		 String lastName= null;
		
		 for(Integer key: usersKeys) {
		
		 Map<String, String> singleUserData = allUsers.get(key);
		 String singleUserName = singleUserData.get("firstName");
		 String singleUserPassword = singleUserData.get("password");
		
		 if(userName.equals(singleUserName) && password.equals(singleUserPassword)) {
		
		 isUser= true;
		 lastName= singleUserData.get("lastName");
		
		 }
		
		 }
		
		
		 if(isUser) {
		
			 SaveUserProperties saveProperties = new SaveUserProperties();
			 saveProperties.saveProperties(userName, password);
		 System.out.println("Login is succesful");
		 System.out.println();
		 System.out.println("***************************************************************************************************");
		 System.out.println();
		 System.out.println("Welcome Mr/Miss: " + userName + " "+ lastName);
		 System.out.println();
		 System.out.println("***************************************************************************************************");
		
		 System.out.println();
		 
		 System.out.println("Instructions to Students:\r\n" + "\n"+
					"1. Attempt 10 questions, each question carries 01 mark\r\n" + 
					"2. No negative Marking\r\n" + 
					"3. For answer enter the correct option \r\n" + 
					"4. Once you entered the answer, you cannot change the answer. Be careful about it.");
		
		 System.out.println();
		 System.out.println("***************************************************************************************************");

		 
			PrintQuestions printQuestions =new PrintQuestions();
			printQuestions.printQ();


		 }else {
		
		 System.out.println("Somthing went wrong plase check the userName and Password");
		
		 }
		
		 }
		
		 public static void main(String[] args) {
		 LoginUser loginUser = new LoginUser();
		
		 loginUser.userLogin();
		
		 }
		
		 }
		



