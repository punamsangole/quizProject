package com.quiz;
import java.io.FileWriter;
import java.io.IOException;

	public class SaveUserProperties {
		public boolean saveProperties(String userName, String password) {

			boolean isDataAdd = false;
			FileWriter fileWriter = null;

			try {

				fileWriter = new FileWriter("C:\\Users\\Rushabh\\Desktop\\userInfo.properties");

				fileWriter.write("userName=" + userName + "\npassword=" + password);
				isDataAdd = true;

			} catch (IOException e) {

				e.printStackTrace();

			} finally {

				try {
					fileWriter.close();
				} catch (IOException e) {

					e.printStackTrace();
				}
			}

			return isDataAdd;

		}
	}


