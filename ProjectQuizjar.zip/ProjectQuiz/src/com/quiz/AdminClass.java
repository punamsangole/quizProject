package com.quiz;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

	public class AdminClass { 
		
	public void Admin1() {
		
		System.out.println("");

		System.out.println("**************WELCOME ADMIN******************");
		



		 Scanner sc = new Scanner(System.in);
	     System.out.println("Please Login>>");
	     System.out.println();
	     System.out.println("Enter the Admin Name>>");
	     String adminName=sc.next();
	     System.out.println("Enter the Admin password>>");
	     String adminPassWord=sc.next();
	     System.out.println();

	   
	     Object adminName1 = "Admin";
		Object adminPassWord1 = "Password123";
		
		if(adminName.equals(adminName1 ) && adminPassWord.equals(adminPassWord1 )) {
	 		System.out.println("Admin Login Successful");
	 		
	 		System.out.println();
	 		
	 		
	 		  boolean adminLogin = true;
	 	     while(adminLogin) {
	 	     System.out.println("Enter 1 : All Students Information");
	 	      System.out.println("Enter 2 : Exit");
	          System.out.println();
	 	     System.out.println("Enter 1 or 2 :");
	 	       int adminLogin1=sc.nextInt();
	 			if(adminLogin1==1) {
	 				adminLogin = false;
	 				AdminClass adminClass = new AdminClass();

	 				adminClass.AdminLogin();
	 			}else if(adminLogin1==2) {
	 				adminLogin = false;
	 	    System.out.println("You selected Exit");
	 			} else {
	 				System.out.println("Enter Wrong input");
	 			
	 					}
	 	}
	 		
			System.out.println();	
			
	     }else {
	   	  System.out.println("Incorrect First Name and Password");
	     }
		
		System.out.println();
		
	}
	    
	    public void DisplayStudents ()  { 
		
		ConnectionClass connectionClass = new ConnectionClass();
		
	    Connection connection = connectionClass.getConnection();
		PreparedStatement prepareStatement = null;
	    try {

		
		prepareStatement  =connection.prepareStatement("select id,firstName,lastName,score from user");

		ResultSet rs=prepareStatement.executeQuery();
		
	    while(rs.next()) {
	   System.out.println(" ID = "+rs.getInt(1));
	   System.out.println();
	   
	   System.out.println(" First Name = "+rs.getString(2));
	   System.out.println();

	   System.out.println(" Last Name = "+rs.getString(3));
	   System.out.println();

	   System.out.println(" Score = "+rs.getInt(4));// check
	   System.out.println();

	    System.out.println();
	   }
	    connection.close();
	   
	    prepareStatement.close();
	    rs.close();

	}

	   catch(Exception e) {
	   e.printStackTrace();
	   }
	 }


	    public void AdminLogin() {
			System.out.println("All Students information are given below :");
            System.out.println();
			DisplayStudents();


				}



	    public static void main(String[] args) {
		AdminClass adminClass = new AdminClass();
		
		adminClass.Admin1();
		
	}
	}



