package com.quiz;
import java.util.Scanner;

	 public class MainClass {
	
	 public void getExecute() {

	 Scanner scanner = new Scanner(System.in);

	 System.out.println("***************************************************************************************************");
	 System.out.println();
	 System.out.println("**********************************WELCOME TO QUIZ APPLICATION*************************************");
	 System.out.println();

	 System.out.println("***************************************************************************************************");
	 System.out.println();

	 System.out.println("Enter 1 : Admin Login ");
	 System.out.println();

	 System.out.println("Enter 2 : Student Login and Quiz ");
	 System.out.println();

	 System.out.println("Enter 3 : Registration");
	 System.out.println();

	 System.out.println("Enter 4 : Get Students All Data");
	 System.out.println();

	 System.out.println("Enter 5 : Exit");
	 System.out.println();


	 
	 System.out.println("Enter between 1 to 5 >>");
	 int checkLogin = scanner.nextInt();
	 System.out.println("***************************************************************************************************");


	 if(checkLogin == 1) {
		 AdminClass adminClass = new AdminClass();
		 adminClass.Admin1();
	 
	 }else if(checkLogin == 2) {
	 
	 
	 LoginUser loginUser= new LoginUser();

	 loginUser.userLogin();

	 }else if(checkLogin == 3) {
	 
	 RegisterUser registerUser = new RegisterUser();
	 
	 registerUser.userRegistration();

	 }else if(checkLogin == 4) {
	 
		 GetDataId getDataId = new GetDataId();
			getDataId.getDataId();
			
	 }else if(checkLogin == 5) {
		 
			System.out.println("You selected Exit.");
			 System.out.println("***************************************************************************************************");

	}else {
	 
			System.out.println("You Entered Wrong input.");

	 }
	 }


	 public static void main(String[] args) {
	 MainClass mainClass = new MainClass();
	 mainClass.getExecute();

	 }

	 }



