package com.quiz;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

		
		
		 public class RegisterUser {
		
		 
		 public void userRegistration() {
		
		 Scanner scanner= new Scanner(System.in);
		 
		 
		
		 System.out.println("Enter the first name: ");
		 String firstName = scanner.next();
		
		 System.out.println("Enter the last name: ");
		 String lastName = scanner.next();
		
		 System.out.println("Enter the password name: ");
		 String password = scanner.next();
			
		 System.out.println("Enter the mobile number: ");
		 String mobileNumber = scanner.next();
		
		 System.out.println("Enter the email address: ");
		 String email = scanner.next();
		
		 ConnectionClass connectionClass = new ConnectionClass();
		
		 Connection con = connectionClass.getConnection();
		
		 try {
		
		 PreparedStatement prepareStatement = 
		con.prepareStatement("insert into user(id,firstName, lastName, userPassword, mobileNumber, email)values(?,?,?,?,?)");
		
		 prepareStatement.setString(1, firstName);
		 prepareStatement.setString(2, lastName);
		 prepareStatement.setString(3, password);
		 prepareStatement.setString(4, mobileNumber);
	     prepareStatement.setString(5, email);
		 int i = prepareStatement.executeUpdate();
		 
		 System.out.println("Student Registration successful");
			System.out.println("Please Login");
            System.out.println();
	       boolean studentLogin = true;
	     while(studentLogin) {
	     System.out.println("Enter 1 : Login");
	      System.out.println("Enter 2 : Exit");
	     System.out.println("Enter 1 or 2>>");
	       int studentLogin1=scanner.nextInt();
			if(studentLogin1==1) {
				studentLogin = false;
					LoginUser loginUser = new LoginUser();
					loginUser.userLogin();
			}else if(studentLogin1==2) {
				studentLogin = false;
	    System.out.println("You selected Exit");
			} else {
				System.out.println("Enter Wrong input");
			
					}
	}
		
		 } catch (SQLException e) {
		
		 e.printStackTrace();
		
		 }
		 }
		 
	}


