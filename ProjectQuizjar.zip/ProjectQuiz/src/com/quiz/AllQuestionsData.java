package com.quiz;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;


	 public class AllQuestionsData { 

	 public Map<Integer, Map<String, String>> getQuestionsData() {

	 Map<Integer, Map<String , String>> allQuestions= new HashMap<>();

	 ConnectionClass connectionClass = new ConnectionClass();
	 Connection connection = connectionClass.getConnection();

	try {
	 PreparedStatement prepareStatement = connection.prepareStatement("select * from questions");
	 ResultSet resultSet = prepareStatement.executeQuery();

	 while(resultSet.next()) {

	 Map<String , String> singleQ= new LinkedHashMap<String, String>();
	
	 int questionNumber = resultSet.getInt(1);
	 String questionBody = resultSet.getString(2);
	 String optionA = resultSet.getString(3);
	 String optionB = resultSet.getString(4);
	 String optionC = resultSet.getString(5);
	 String optionD = resultSet.getString(6);
	 String ans = resultSet.getString(7);

	 singleQ.put("questionBody", questionBody);
	 singleQ.put("optionA", optionA);
	 singleQ.put("optionB", optionB);
	 singleQ.put("optionC", optionC);
	 singleQ.put("optionD", optionD);
	 singleQ.put("ans", ans);

	 allQuestions.put(questionNumber, singleQ);
	 }

	 } catch (SQLException e) {
	 
	 e.printStackTrace();
	 }

	 return allQuestions;

	 } 
	 

	 public static void main(String[] args) {

	 AllQuestionsData allQuestionsData = new AllQuestionsData();
	 System.out.println(allQuestionsData.getQuestionsData());

	 }

	 }


