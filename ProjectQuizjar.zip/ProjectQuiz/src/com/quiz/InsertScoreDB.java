package com.quiz;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

	public class InsertScoreDB {

		

		public boolean saveScore(int score) {

			boolean isScoreUpdate = false;

			
			GetUserID getUserID = new GetUserID();

			Integer userId = getUserID.getUserId();

			
			ConnectionClass connectionClass = new ConnectionClass();

			Connection connection = connectionClass.getConnection();
			PreparedStatement prepareStatement = null;

			try {

				prepareStatement = connection.prepareStatement("update user set score =? where id= ?");// updating score

				prepareStatement.setInt(1, score);
				prepareStatement.setInt(2, userId);

				int i = prepareStatement.executeUpdate();

				if (i != 0) {

					isScoreUpdate = true;

				}

			} catch (SQLException e) {

				e.printStackTrace();

			} finally {
				try {
					connection.close();
					prepareStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return isScoreUpdate;
		}

		public static void main(String[] args) {
			

		}
	}


