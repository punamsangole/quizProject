package com.quiz;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;


	 public class AllUserData {

	 
	 public Map<Integer, Map<String, String>> getUsers() {

	 Map<Integer, Map<String, String>> allUserData = new LinkedHashMap<>();

	 ConnectionClass connectionClass = new ConnectionClass();

	 Connection connection = connectionClass.getConnection();

	 try {

	 PreparedStatement prepareStatement = connection.prepareStatement("select * from user");

	 ResultSet result = prepareStatement.executeQuery();

	 while(result.next()) {

	 Map<String, String> singleUserData= new LinkedHashMap<String, String>();

	 int userId = result.getInt(1);
	 String firstName = result.getString(2);
	 String lastName = result.getString(3);
	 String password = result.getString(4);
	 String mobileNumber = result.getString(5);
	 String email = result.getString(6);


	 singleUserData.put("firstName", firstName);
	 singleUserData.put("lastName", lastName);
	 singleUserData.put("password", password);
	 singleUserData.put("mobileNumber", mobileNumber);
	 singleUserData.put("email", email);

	 allUserData.put(userId, singleUserData);


	 }


	 } catch (SQLException e) {

	 e.printStackTrace();

	 }

	 return allUserData;
	 }

	 public static void main(String[] args) {
	 AllUserData allUserData = new AllUserData();

	 System.out.println(allUserData.getUsers());
	 }

	 }


