
package com.quiz;
	public class GetDataId {
		public void getDataId() {
			
			 
				AdminClass adminClass = new AdminClass();
				adminClass.DisplayStudents();

		}
		public static void main(String[] args) {
			GetDataId getDataId = new GetDataId();
			getDataId.getDataId();
			
		}

		
	}


