package com.quiz;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class GetUserID {

	
	public Integer getUserId() {

		
		Integer userId = null;
		String userName = null;
		String password = null;
		FileInputStream fileInputStream = null;
		Properties properties = null;

		try {
			fileInputStream = new FileInputStream("C:\\Users\\Rushabh\\Desktop\\userInfo.properties");

			properties = new Properties();

			properties.load(fileInputStream);
			;

			userName = properties.getProperty("userName");
			password = properties.getProperty("password");

		} catch (FileNotFoundException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		} finally {

			try {
				fileInputStream.close();
				properties.clone();

			} catch (IOException e) {

				e.printStackTrace();
			}

		}
		
		AllUserData allUserData = new AllUserData();

		Map<Integer, Map<String, String>> allUsers = allUserData.getUsers();

		Set<Integer> keySet = allUsers.keySet();

		for (Integer key : keySet) {

			Map<String, String> singleUser = allUsers.get(key);

			String singleUserName = singleUser.get("firstName");
			String singleUserPassword = singleUser.get("password");

			if (userName.equals(singleUserName) && password.equals(singleUserPassword)) {
				userId = key;
			}
		}

		return userId;
	}

	public static void main(String[] args) {
		

	}
}


